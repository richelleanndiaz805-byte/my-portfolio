$(document).ready(function(){
    $("p").css("color", "black")
    $("h1").css("color", "pink")
    $("p.into").css("color", "black")

$("#title").text("GOOD MORNING BABY >.<")

$(".colorbtn").click(function(){
    $(this).css("background", "pink")
    $("Table").hide(slow)
})

$("p:first").css("color","pink" )

$("ul li:first-child").css("color", "maroon")

$("[href]").css("color", "red")

$("tr:even").css("backgorund", "blue")
$("tr:odd").css("background", "pink")


$("#btn").click(function(){
    $("#Message").text("You clicked the button!")

$(this).css("background", "yellow")    
})

$("#btn").dblclick(function(){
$("#Message").text("You clicked the button!")
$(this).css("background", "orange")
$(this).css("color", "violet")
$("Table").show(1000)
})


$("#btn").mouseenter(function(){
    $("#Message").text("You mouse reach the button!")
})

$("#btn").mouseleave(function(){
    $("#Message").text("You mouse leaves the button!")
})

$("#name").focus(function(){
$("#Message").text("typing....")
$(this).css("background", "maroon")
})

$("#name").blur(function(){
    $(this).css("background", "white")
    $("#Message").text("waiting....")
})

$("#course").change(function(){
    $("#Message").text($(this).val())
})




})
