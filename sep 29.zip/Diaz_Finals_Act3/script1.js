$(document).ready(function(){

$("btn1").click(function(){
    $("#title").text("Welcome, Students!")})


$(".colorbtn").click(function(){
    $(this).css("background", "pink")
    $("card").hide(slow)})






})