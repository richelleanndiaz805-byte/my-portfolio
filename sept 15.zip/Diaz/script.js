console.log(document)

const var1 = document.getElementById("b")
console.log(var1)

const BTN = document.getElementById("btn1")
console.log(BTN)

const DBTN = document.getElementById("dbtn1")
console.log(DBTN)

const IMG = document.getElementById("image")
console.log(IMG)

BTN.addEventListener(
    "click", function () {
       var1.innerHTML = "Morning"
       var1.style.color = "pink"
    }
)

DBTN.addEventListener(
    "dblclick", function () {
       var1.innerHTML = "Helloooo"
       var1.style.color = "SkyBlue"
    }
)

IMG.addEventListener(
    "mouseout", function(){
        var1.innerHTML = "Your mouse leave the img"
    }
)

IMG.addEventListener(
    "mouseover", function (){
        var1.innerHTML = "Your mouse enter the img"
    }
)

const INPUT = document.getElementById("input")
console.log(INPUT)

INPUT.addEventListener(
    "change", function (){
        var1.innerHTML = "HELLO " + INPUT.value + "!"
    }
)

INPUT.addEventListener(
    "input", function (){
        var1.innerHTML = "HELLO "  + INPUT.value + "!"
    }
)

INPUT.addEventListener (
    "focus", function () {
        INPUT.style.background = "Pink"
    }
)

// INPUT.addEventListener(
//     "mouseover", function () {
//         INPUT.style.backgroundColor = "Yellow"
//     }
// )

INPUT.addEventListener(
    "blur", function () {
        INPUT.style.backgroundColor = "blue"
    }
)
