console.log(document)

const IMG = document.getElementById("img")
console.log(IMG)

IMG.addEventListener(
    "mouseout", function(){
        var1.innerHTML = "Image is active."
    }
)

const var1 = document.getElementById("hi")
console.log(var1)

const var2 = document.getElementById("hello")
console.log(var2)

const INPUT = document.getElementById("input")
console.log(INPUT)

INPUT.addEventListener(
    "change", function (){
        var1.innerHTML = "" + INPUT.value + "!"
    }
)

INPUT.addEventListener(
    "input", function (){
        var1.innerHTML = ""  + INPUT.value + "!"
    }
)

INPUT.addEventListener (
    "focus", function () {
        INPUT.style.background = "Pink"
    }
)

INPUT.addEventListener(
    "blur", function () {
        INPUT.style.background = "Sky Blue"
    }
)

const SELECT = document.getElementById("select")
console.log(SELECT)

SELECT.addEventListener(
   "focus", function() {
        SELECT.style.background = "Pink"
   } 
)

const BTN = document.getElementById("btn1")
console.log(BTN)

BTN.addEventListener(
    "click", function(){
        
    }
)

const DBTN = document.getElementById("dbtn1")
console.log(DBTN)
